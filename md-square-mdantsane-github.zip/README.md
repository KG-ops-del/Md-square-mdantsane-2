# MD SQUARE MDANTSANE Website

## Quick Start - Upload to GitHub Pages

### Step 1: Create GitHub Account
- Go to https://github.com/signup
- Use email: your-email@example.com
- Choose username: md-square-mdantsane (or your preference)

### Step 2: Create New Repository
1. Click "+" icon → "New repository"
2. Name: `md-square-mdantsane`
3. Make it **Public**
4. Click "Create repository"

### Step 3: Upload These Files
1. In your repo, click "Add file" → "Upload files"
2. Upload ALL files from this folder:
   - `index.html` (the website)
   - `CNAME` (custom domain config)
3. Click "Commit changes"

### Step 4: Enable GitHub Pages
1. Go to Settings → Pages (left sidebar)
2. Source: "Deploy from a branch"
3. Select "main" branch, "/ (root)" folder
4. Click "Save"
5. Your site is live at: `https://YOUR_USERNAME.github.io/md-square-mdantsane`

### Step 5: Add Custom Domain (Optional)
1. In Settings → Pages → Custom domain
2. Enter: `mdsquaremdantsane.co.za`
3. Click "Save"
4. At your domain registrar, add these DNS records:
   - A Record: @ → 185.199.108.153
   - A Record: @ → 185.199.109.153
   - A Record: @ → 185.199.110.153
   - A Record: @ → 185.199.111.153
   - CNAME: www → YOUR_USERNAME.github.io

### Step 6: Share on WhatsApp
Copy your live link and paste directly in WhatsApp:
```
https://mdsquaremdantsane.co.za
```
WhatsApp will automatically show a preview card.

---

## Files in This Package

| File | Purpose |
|------|---------|
| `index.html` | The complete website (mobile-optimized) |
| `CNAME` | Tells GitHub your custom domain |
| `README.md` | This instructions file |

---

## Mobile Features
- Responsive design for all screen sizes
- Touch-friendly buttons (44px minimum tap target)
- Fast loading (no external images)
- WhatsApp preview optimized with Open Graph meta tags
- Smooth scroll animations
- Hamburger menu for mobile navigation

---

## Need Help?
Contact support or search "GitHub Pages custom domain tutorial" on YouTube.
